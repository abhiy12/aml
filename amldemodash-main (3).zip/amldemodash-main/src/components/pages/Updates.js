import React from "react";
import { Paper } from "@mui/material";
function Updates() {

  return (  
  <Paper>
    <h1>Updates page</h1>
  </Paper>

  );
}
export default Updates;


