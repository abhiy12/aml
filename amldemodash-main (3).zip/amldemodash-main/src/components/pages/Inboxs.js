import React from "react";
import '../pages/inboxs.css';
function Inboxs(){
return(
    <div className="title1">
<h1 >Inbox</h1>
</div>
);

}
export default Inboxs;
