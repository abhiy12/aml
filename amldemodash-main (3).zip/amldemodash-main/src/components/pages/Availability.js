import React from 'react'
// import FullCalendar from '@fullcalendar/react' ;// must go before plugins
// import dayGridPlugin from '@fullcalendar/react';
 function Availability()  {

    return (
      // <FullCalendar
      //   plugins={[ dayGridPlugin ]}
      //   initialView="dayGridMonth"
      //   events="https://fullcalendar.io/demo-events.json?start-2021-03-22&end-2021-08-22"
      //   headerToolbar={{
      //     left:"prev,next",
      //     center:"title",
      //     right:"today,dayGridDay,dayGridWeek,dayGridMonth",
      //   }}
      // />
      <h1> Availability </h1>
    );
  
}
export default Availability;


