import React from "react";
import { Paper } from "@mui/material";
function Workhistory() {

  return (  <h1>Work History page</h1>

  );
}
export default Workhistory;


