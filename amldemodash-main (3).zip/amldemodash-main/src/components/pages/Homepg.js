import React from "react";
import { Paper } from "@mui/material";
import '../pages/homepg.css'
function Homepg() {

  return (  
    <div className="title">
<h1 >Home page</h1>
</div>
  );
}
export default Homepg;
